/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client_conection;
import client_bl.*;
/**
 *
 * @author miguel
 */
public class Protocol {
        
    private static Sockets sc;
    private static boolean connected = false;
    
   
     //O método connect cria um objecto do tipo Sockets. O construtor estabelece a conexão, alterando-se a variável connected para true
     public static void  disconnect(){
        connected = false;
    }
    
    public static void connect(){
        if (!connected)
            sc = new Sockets();
        connected = true;
        System.out.println("Reception");
         }

    public static boolean isConnected() {
        return connected;
    }
    
    
     //O método sendLogin recebe o user e a password encriptada e mete os numa string.  
     //Envia a string para o server através da função send espera a resposta.
     
 
    public static String sendLogin(String user, String password){
        
       
        
        connect();
        String toSend = "Login#"+user+"#"+password;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
                           
        receivedReply = sc.receive(); 
        System.out.println(receivedReply);
        System.out.append(receivedReply);
        disconnect();
        if("clean".equals(receivedReply))
        return "falhou_a_conexao";
        else return receivedReply;
       }
    public static String sendResgister(Player player)
    {
        connect();
        System.out.print(player.getPassword()+"entrou no sendRegister");
        String toSend = "Register#"+player.getUser()+"#"+player.getFirst_name()+"#"+player.getLast_name()+"#"+player.getPassword()+"#"+player.getEmail()+"#"+player.getRank()+"#"+player.getAge();
        System.out.println("passou 1");
        System.out.println(toSend);
         System.out.println("passou 2");
        
         
         String receivedReply;
         System.out.println("passou 3");
        System.out.println(toSend);
         System.out.println("passou 4");
        sc.send(toSend);
                           
        receivedReply = sc.receive(); 
        System.out.println("passou 5");
        System.out.append(receivedReply);
        disconnect();
        if("ERRO".equals(receivedReply))
            System.out.println(" just erro" );
        if("clean".equals(receivedReply))
        return "falhou_a_conexao";
        else return receivedReply;
    } /*
    public static String sendBoat1(String coordinates1){
         connect();
        String toSend = "Boat1#"+lenght+"#"+coordinates1;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
                           
        receivedReply = sc.receive();// you will receive OK or FAILL
        
        return null;} 
    

    public static String sendBoat2(String coordinates1, String coordinates2 ){
       connect();
        String toSend = "Boat2#"+lenght+"#"+coordinates1"#"+coordinates2;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
                   // you will receive OK or FAILL        
        receivedReply = sc.receive();  

        
        
        
        return null;} 
    
    public static String sendBoat3(String coordinates1, String coordinates2, String coordinates3){
        connect();
        String toSend = "Boat3#"+lenght+"#"+coordinates1"#"+coordinates2"#"+coordinates3;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
                   // you will receive OK or FAILL        
        receivedReply = sc.receive();
        
        
        
        return null;} 
    public static String sendBoat4(String coordinates1, String coordinates2, String coordinates3, String coordinates4){
        connect();
        String toSend = "Boat4#"+lenght+"#"+coordinates1"#"+coordinates2"#"+coordinates3"#"+coordinates4;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
            // you will receive OK or FAILL               
        receivedReply = sc.receive();
        
        
        
        
        return null;}
    public static String sendBoat5(String coordinates1, String coordinates2, String coordinates3, String coordinates4, String coordinates5){
        connect();
        String toSend = "Boat5#"+lenght+"#"+coordinates1"#"+coordinates2"#"+coordinates3"#"+coordinates4"#"+coordinates5;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
                           
        receivedReply = sc.receive();
        // you will receive OK or FAILL
        
        
        
        return null;
    } 
    public static String doShots(){
        connect();
        String toSend = "Shot#"+nºmove+"#"+coordinates;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
                           
        receivedReply = sc.receive();
        //  send the position of shot
        
        return null;} 
    
    public static String receiveShots(){
        connect();
        String toSend = "LastShot#"+nº Move+"#"+coordinates;
        String receivedReply;
        System.out.println(toSend);
        sc.send(toSend);
                           
        receivedReply = sc.receive();
        // received the position of shot on last move
        
        
        return null;}
*/
}
